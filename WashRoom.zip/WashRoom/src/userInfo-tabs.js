import React from 'react'
import { Tabs, useTabState, Panel } from '@bumaga/tabs'
import LoginForm from './NoteloginForm';
import VendorPanel from './NoteVendorInfo';


const cn = (...args) => args.filter(Boolean).join(' ')

const Tab = ({ children }) => {
  const { isActive, onClick } = useTabState()

  return (
    <button className={cn('tab', isActive && 'active')} onClick={onClick}>
      {children}
    </button>
  )
}

export default () => (
  <div className="out-border">
  <Tabs>
    <div className='tabs'>
      <div className='tab-list'>
        <Tab>User Information</Tab>

        <Tab>Vendor Information </Tab>

        <Tab>Service</Tab>

        <Tab>Uplpoad Profile</Tab>
      </div>
      <Panel>
        <LoginForm />
      </Panel>
      <Panel>
      <VendorPanel />
      </Panel>
      <Panel>
        <p>
          Creates a MotionValue that, when set, will use a spring animation to
          animate to its new state.
        </p>
      </Panel>
    </div>
  </Tabs>
  
  </div>
)
