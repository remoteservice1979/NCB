import React,{ Component } from 'react'
import { Panel } from '@bumaga/tabs'
import NoteVendorInfo from './NoteVendorInfo';

export default class VendorPanel extends Component{
  render() {
    return (
      <Panel>
         <NoteVendorInfo />
      </Panel>
    );
  }
}